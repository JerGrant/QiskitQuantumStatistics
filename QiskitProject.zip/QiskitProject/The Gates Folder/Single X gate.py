%matplotlib inline
from qiskit import QuantumCircuit, execute, Aer, IBMQ
from qiskit.compiler import transpile, assemble
from qiskit.tools.jupyter import *
from qiskit.visualization import *
provider = IBMQ.load_account()

#Initial Circuit
circuit = QuantumCircuit(1, 1)
circuit.draw()

# Turn 1 Quantum Computer puts qbit into Superposition applies 1 H gate
circuit.x(0)

# Measure
circuit.measure([0], [0])
circuit.draw()

# run in a simulator
backend = Aer.get_backend('qasm_simulator')

# execute the job in 1 shot, run it multiple times to get a different results
job = execute(circuit, backend, shots=1000)
counts = job.result().get_counts(circuit)


print("Result:", counts)

if '0' in counts.keys():
    print("tail")
else:
    print("head")

plot_histogram(counts)
