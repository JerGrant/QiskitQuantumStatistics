#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <string>
using namespace std;

int randomNum(int num);

int main()
{
	int num = 0;
	string choice = "";
	int heads = 0;
	int tails = 0;
	int correct = 0;
	int wrong = 0;
	srand(time(0));
	string usrInput;

	cout << "Welcome to Coin Toss" << endl;


	for (int plays = 1; plays <= 10; ++plays) {

		int flips = 0;
		cout << "Heads or Tails? Type H or T:" << endl;
		cin >> usrInput;


		do {
			num = randomNum(num);
			if (num == 1) {
				choice = "H";
				++heads;
			}
			else {
				choice = "T";
				++tails;
			}
			++flips;
			cout << choice;
		} while (plays > 10);

		cout << endl;

		if (choice == usrInput)
		{
			cout << "You guessed correctly!" << endl;
			++correct;
		}
		else {
			cout << "You guessed incorrectly." << endl;
			++wrong;
		}

	}
	cout << endl;
	cout << "Number of Heads: " << heads << endl;
	cout << "Number of Tails: " << tails << endl;
	cout << "You were right " << correct << " times!" << endl;
	return 0;
}

// Return a random number 1 or 2
int randomNum(int num) {
	num = 1 + rand() % 2;
	return num;
}