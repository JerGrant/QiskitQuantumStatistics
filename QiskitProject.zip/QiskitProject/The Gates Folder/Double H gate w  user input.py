from qiskit import QuantumCircuit, Aer, IBMQ, QuantumRegister, ClassicalRegister, execute
from qiskit.tools.jupyter import *
from qiskit.visualization import *
import qiskit.tools.jupyter
import ipywidgets as widgets

# Layout
print("Apply X or I gate to trip up Quantum Computer")
button_p = widgets.Button(
    description='Coin Flip!')
gate_p = widgets.Dropdown(options=[('Identity Gate', 'i'), ('Flip the Coin X Gate', 'x')],disabled=False,)


out_p = widgets.Output()
def on_button_clicked(b):
    with out_p:
        
        # Initial Circuit
        circuit_p = QuantumRegister(1, 'circuit')
        measure_p = ClassicalRegister(1, 'result')
        circuit = QuantumCircuit(circuit_p, measure_p)
        
        # Apply 1st H gate 50% certainity
        circuit.h(circuit_p[0])
        
        # User input, apply x or i gate to trip up quantum computer
        if gate_p.value == 'i':
            circuit.i(circuit_p[0])
        if gate_p.value == 'x':
            circuit.x(circuit_p[0])
        
        # Apply 2nd H gate, 100% certainity 
        circuit.h(circuit_p[0])
        
        # Measure  
        circuit.measure(circuit_p, measure_p)
        
        # QASM
        backend_p = Aer.get_backend('aer_simulator')
        job = execute(circuit, backend_p, shots=1000)
        counts = job.result().get_counts()
        
        # Results
        print("Result:", counts)
        if len(counts) == 1 and list(counts.keys())[0] == '0':
            print("Quantum Computer guessed correctly")
        if len(counts) == 1 and list(counts.keys())[0] == '1':
            print("Quantum Computer was wrong")

button_p.on_click(on_button_clicked)
widgets.VBox([gate_p, button_p, out_p])